// objective: test the \namespace command
// check: namespace_n_s.xml

namespace NS 
{
}

/** @namespace NS
 *  A namespace 
 */
