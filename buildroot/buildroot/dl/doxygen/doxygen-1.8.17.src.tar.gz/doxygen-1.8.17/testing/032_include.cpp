// objective: test the \include and \includelineno commands
// check: indexpage.xml

/** \mainpage 
 *  Some text.
 *  \include example_test.cpp
 *  More text.
 *  \includelineno example_test.cpp
 *  End.
 */
