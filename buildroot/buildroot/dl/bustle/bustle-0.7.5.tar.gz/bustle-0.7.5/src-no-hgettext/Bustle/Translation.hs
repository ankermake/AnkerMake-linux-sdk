module Bustle.Translation
    (
      initTranslation
    , __
    )
where

initTranslation :: IO ()
initTranslation = return ()

__ :: String -> String
__ = id
