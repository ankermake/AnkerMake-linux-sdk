#!/bin/sh
make || exit
killall dbus-triggerd

### switch to sound 'hw:0' on any DeviceError
# This requires a patched JACK2, that sends a DeviceError
./dbus-triggerd $@ "type='signal',path=/org/jackaudio/Controller,interface=org.jackaudio.JackControl,member=DeviceError" --shell "myjackctl.sh alsa hw:0" &

# This an alternative to the above, using the HAL message
#dbus-triggerd $@ --system "type='signal',path=/org/freedesktop/Hal/Manager,interface=org.freedesktop.Hal.Manager,member=DeviceRemoved,arg0=/org/freedesktop/Hal/devices/usb_device_582_74_noserial_if0_sound_card_2" --shell "myjackctl.sh alsa hw:0" &

### switch to external USB sound device 'hw:2' when it's connected
./dbus-triggerd $@ --system "type='signal',path=/org/freedesktop/Hal/Manager,interface=org.freedesktop.Hal.Manager,member=DeviceAdded,arg0=/org/freedesktop/Hal/devices/usb_device_582_74_noserial_if0_sound_card_2" --shell "myjackctl.sh alsa hw:2" &
